require("core.options")
require("core.keymaps")
require("core.terminal")
