# <img src="https://github.com/user-attachments/assets/4c636831-38fd-43b8-9ab7-d154574145d9" hspace="10" width="37"  align="left"/><p><center>Preview FastCat Themes</center>
<details>
<summary>Large-Themes</summary>
  
  Anime-Boy
  --
  
 <img src="https://github.com/user-attachments/assets/2ebeab84-1026-4143-9efa-f906e98940b4"><br>

  Anime-Girl
  --
  <img src="https://github.com/user-attachments/assets/1b56da0c-dc8c-48a9-9567-e96e497920ca" width="700" >
  
  Cat
  --
  
  <img src="https://github.com/user-attachments/assets/65eaa658-4647-4c83-962e-26f1cf212a07"><br>
  
  Saturn
  --
  <img src="https://github.com/user-attachments/assets/bb576812-f45a-4f48-b0bd-638157d765f7">

  Suse-Icons
  --
  <img src="https://github.com/user-attachments/assets/022e5b71-9fdf-4065-b24e-724065a1a36d">

  BatMan
  --
  <img src="https://github.com/user-attachments/assets/4f034abd-5fc4-48f8-852f-bd3051ef3d61">

  Jurassic
  --
  <img src="https://github.com/user-attachments/assets/721c26a4-e257-4143-8039-21cda93c2d2c">

  Scorpion
  --
  <img src="https://github.com/user-attachments/assets/81ceb07a-bab4-493c-a77e-4a05062904fd">

  Pentagram
  --
  <img src="https://github.com/user-attachments/assets/b68a6c35-461c-44c8-9f5c-ad190491599f">

  Death
  --
  <img src="https://github.com/user-attachments/assets/bc79bef2-4f37-48b9-82c0-d74c1bde82a6" width="700" >

  Simpsons
  --
  <img src="https://github.com/user-attachments/assets/1cef4cda-62e4-424c-9c27-77ff984b9afb" width="700">

  Rose
  --
  <img src="https://github.com/user-attachments/assets/178fa1f8-fbb2-4124-90f1-9196648e7b1b" width="700">

  Origami
  --
  <img src="https://github.com/user-attachments/assets/dd44b18e-4db7-48a1-96c0-828c87bba98d" width="700">

  Fedora
  --
  <img src="https://github.com/user-attachments/assets/5e98c3be-9371-4a60-87d2-0f0e9b58bcca" width="700">
  
  Arch
  --
  <img src="https://github.com/user-attachments/assets/49c743cc-6095-4b08-9253-7ddd1418e5f3" width="700">

  Groups
  --
  <img src="https://github.com/user-attachments/assets/1f81438a-5797-4abb-b01a-debe886c80e7" width="700">

  MetoCat
  --
  <img src="https://github.com/user-attachments/assets/0be640df-ca9d-4a3a-9a9c-cc39f764abc7" width="700">

SpiderMan
--
 <img src="https://github.com/user-attachments/assets/554abc45-0b2d-467c-8cc0-f26a65d64cfe" width="700">

SuperMan
--
 <img src="https://github.com/user-attachments/assets/f075c6cb-7a13-48d0-930b-ef89889096af">

Home
--
<img src="https://github.com/user-attachments/assets/16d6adaf-64ea-4bbe-90fd-4a5cb7b86e81">

DeadPool
--
<img src="https://github.com/user-attachments/assets/edac3042-ab3c-48a5-ae7b-ae014c6607cd">

Triangle
--
<img src="https://github.com/user-attachments/assets/2331b32a-8845-4c74-8c09-6e69658f1aca">

</details>
<details>
<summary>Small-Themes</summary>

  MetoSpace
  --
  <img src="https://github.com/user-attachments/assets/e7aba1e8-b670-4c25-8266-ae2e2dac8903">

  Fast-Snail
  --
  <img src="https://github.com/user-attachments/assets/eb7fbba4-1369-4ea9-9587-48779f1ffa7b">

  Cat
  --
  <img src="https://github.com/user-attachments/assets/6f5e8a76-f8cb-4523-9d3d-145c8fd59581" width="300">

  Arch
  --
  <img src="https://github.com/user-attachments/assets/c1ff38ea-59ed-440c-944f-5cc13d1c0b6c">

  Minimal
  --
  <img src="https://github.com/user-attachments/assets/9c375e68-a813-435d-bf19-73571993db7a">

  Sheriff
  --
  <img src="https://github.com/user-attachments/assets/9765b619-3048-43db-9beb-6ef25aacb680">

  Palm
  --
  <img src="https://github.com/user-attachments/assets/351b51d0-9852-4c4c-a8ea-a9c6d169c47b">

  Duck
  --
  <img src="https://github.com/user-attachments/assets/8ade2125-9a29-45db-aece-b5baf5a7ff7e">

  Cocktail
  --
  <img src="https://github.com/user-attachments/assets/a0d730fb-fdfe-4ba8-ae96-d8d988b631e0">

  Blocks
  --
  <img src="https://github.com/user-attachments/assets/e8c3db08-a77d-474f-afab-da6472286cb9">
</details>
</details>
<a href="https://m3tozz.github.io/FastCat-Themes/">https://m3tozz.github.io/FastCat-Themes/</a><br>
